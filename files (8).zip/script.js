document.addEventListener("DOMContentLoaded", function () {
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.querySelector(".main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      nav.classList.toggle("open");
    });
  }

  var revealEls = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window && revealEls.length) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("in");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add("in"); });
  }

  // ---- Contact / enquiry form: submits to Runwal Plast's inbox via FormSubmit ----
  var form = document.querySelector(".inquiry");
  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var btn = form.querySelector("button[type=submit]");
      var status = form.querySelector(".form-status");
      var original = btn.textContent;
      btn.textContent = "Sending...";
      btn.disabled = true;

      var data = new FormData(form);
      fetch(form.action, {
        method: "POST",
        body: data,
        headers: { Accept: "application/json" }
      })
        .then(function (res) {
          if (!res.ok) throw new Error("send failed");
          btn.textContent = "Enquiry Sent";
          if (status) {
            status.textContent = "Thanks! Your enquiry has been sent — we'll get back to you shortly.";
            status.className = "form-status show ok";
          }
          form.reset();
        })
        .catch(function () {
          btn.textContent = original;
          if (status) {
            status.textContent = "Something went wrong. Please call or WhatsApp us directly instead.";
            status.className = "form-status show err";
          }
        })
        .finally(function () {
          btn.disabled = false;
          setTimeout(function () {
            btn.textContent = original;
          }, 3000);
        });
    });
  }

  // ---- Product illustrations + click-to-view modal ----
  var illustrations = {
    automotive: '<svg viewBox="0 0 200 200"><rect x="20" y="90" width="160" height="55" rx="14" fill="#2b2f36"/><rect x="35" y="70" width="130" height="40" rx="18" fill="#3a4048"/><circle cx="55" cy="150" r="16" fill="#1a1d22"/><circle cx="145" cy="150" r="16" fill="#1a1d22"/><circle cx="55" cy="150" r="6" fill="#7c8a96"/><circle cx="145" cy="150" r="6" fill="#7c8a96"/><rect x="70" y="95" width="60" height="10" rx="3" fill="#e15b22"/></svg>',
    containers: '<svg viewBox="0 0 200 200"><rect x="35" y="80" width="55" height="80" rx="4" fill="#eef1f2" stroke="#7c8a96" stroke-width="2"/><rect x="35" y="70" width="55" height="14" rx="3" fill="#2b2f36"/><rect x="105" y="60" width="60" height="100" rx="4" fill="#eef1f2" stroke="#7c8a96" stroke-width="2"/><rect x="105" y="48" width="60" height="16" rx="3" fill="#e15b22"/></svg>',
    hangers: '<svg viewBox="0 0 200 200"><circle cx="100" cy="45" r="8" fill="#2b2f36"/><path d="M100 53v14" stroke="#2b2f36" stroke-width="4"/><path d="M30 130 L100 70 L170 130 Z" fill="none" stroke="#e15b22" stroke-width="7" stroke-linejoin="round"/><rect x="20" y="128" width="160" height="8" rx="4" fill="#e15b22"/></svg>',
    electrical: '<svg viewBox="0 0 200 200"><rect x="45" y="35" width="110" height="130" rx="6" fill="#f4f4f4" stroke="#7c8a96" stroke-width="2"/><rect x="65" y="60" width="30" height="45" rx="4" fill="#2b2f36"/><rect x="105" y="60" width="30" height="45" rx="4" fill="#2b2f36"/><circle cx="80" cy="130" r="5" fill="#e15b22"/><circle cx="120" cy="130" r="5" fill="#e15b22"/></svg>',
    bottles: '<svg viewBox="0 0 200 200"><rect x="75" y="70" width="50" height="95" rx="8" fill="#eef1f2" stroke="#7c8a96" stroke-width="2"/><rect x="88" y="45" width="24" height="30" rx="4" fill="#eef1f2" stroke="#7c8a96" stroke-width="2"/><rect x="80" y="30" width="40" height="18" rx="4" fill="#e15b22"/></svg>',
    household: '<svg viewBox="0 0 200 200"><path d="M45 80 h110 l-12 85 a8 8 0 01-8 7 H65 a8 8 0 01-8-7 Z" fill="#eef1f2" stroke="#7c8a96" stroke-width="2"/><path d="M60 80 a40 40 0 0180 0" fill="none" stroke="#e15b22" stroke-width="7"/></svg>',
    chairs: '<svg viewBox="0 0 200 200"><rect x="55" y="35" width="90" height="55" rx="8" fill="#d1442a"/><rect x="55" y="95" width="90" height="14" rx="4" fill="#d1442a"/><rect x="60" y="109" width="10" height="55" fill="#b8371f"/><rect x="130" y="109" width="10" height="55" fill="#b8371f"/><rect x="60" y="150" width="80" height="8" fill="#8a2c17"/></svg>',
    baskets: '<svg viewBox="0 0 200 200"><path d="M50 80 h100 l-10 78 a10 10 0 01-10 9 H70 a10 10 0 01-10-9 Z" fill="#3f9e5c" stroke="#2c7a43" stroke-width="2"/><path d="M50 80 h100 M58 95 h84 M62 112 h76 M66 129 h68" stroke="#2c7a43" stroke-width="3" fill="none"/><path d="M70 80 a30 26 0 0160 0" fill="none" stroke="#2c7a43" stroke-width="6"/></svg>',
    pipes: '<svg viewBox="0 0 200 200"><rect x="30" y="85" width="80" height="30" rx="4" fill="#c7ced3" stroke="#7c8a96" stroke-width="2"/><rect x="100" y="70" width="30" height="60" rx="4" fill="#c7ced3" stroke="#7c8a96" stroke-width="2"/><rect x="120" y="85" width="55" height="30" rx="4" fill="#c7ced3" stroke="#7c8a96" stroke-width="2"/></svg>',
    toys: '<svg viewBox="0 0 200 200"><rect x="82" y="28" width="36" height="20" rx="5" fill="#2b2f36"/><path d="M50 50 h100 l-20 100 a19 19 0 01-30 13 a19 19 0 01-30-13 z" fill="#e15b22"/><rect x="50" y="78" width="100" height="16" fill="#3a7ec4"/><rect x="56" y="112" width="88" height="14" fill="#f0b429"/></svg>',
    crates: '<svg viewBox="0 0 200 200"><rect x="35" y="55" width="130" height="95" rx="4" fill="#3a7ec4" stroke="#2b5f96" stroke-width="2"/><path d="M35 80h130M35 105h130M35 130h130M68 55v95M101 55v95M134 55v95" stroke="#2b5f96" stroke-width="2.5"/></svg>',
    pots: '<svg viewBox="0 0 200 200"><path d="M55 75 h90 l-14 85 a8 8 0 01-8 7 H77 a8 8 0 01-8-7 Z" fill="#d97b3f" stroke="#b8622e" stroke-width="2"/><ellipse cx="100" cy="75" rx="45" ry="10" fill="#e08a4f" stroke="#b8622e" stroke-width="2"/><path d="M100 65 C90 40 70 40 65 25 C85 25 95 40 100 65 C105 40 115 25 135 25 C130 40 110 40 100 65Z" fill="#3f9e5c"/></svg>',
    stationery: '<svg viewBox="0 0 200 200"><rect x="55" y="35" width="70" height="120" rx="4" fill="#3a7ec4"/><rect x="65" y="52" width="50" height="6" fill="#fff"/><rect x="65" y="68" width="50" height="6" fill="#fff"/><rect x="65" y="84" width="32" height="6" fill="#fff"/><path d="M128 55 L150 33 L165 48 L143 70 L123 74 Z" fill="#e15b22"/><path d="M143 70 L123 74 L128 55 Z" fill="#a83f14"/></svg>'
  };
  var productInfo = {
    automotive: ["Automotive Plastic Parts", "Durable moulded components engineered for vehicle systems."],
    containers: ["Plastic Containers", "Sturdy, food-safe and industrial storage containers in various sizes."],
    hangers: ["Plastic Hangers & Utility Items", "Lightweight, long-lasting hangers and everyday utility items."],
    electrical: ["Electrical Fittings", "Precision-moulded switch plates, fittings, and housings."],
    bottles: ["Bottles & Dispensers", "Leak-proof bottles and dispensers for household and industrial use."],
    household: ["Household Plastic Products", "Everyday household products built for daily durability."],
    chairs: ["Furniture", "Moulded plastic furniture — chairs, stools, and tables designed for strength and comfort."],
    baskets: ["Plastic Baskets", "Ventilated, stackable baskets for storage and transport."],
    pipes: ["Pipes & Pipe Fittings", "Reliable pipes and fittings for plumbing and construction."],
    toys: ["Toys", "Safe, colourful, durable plastic toys moulded to precise standards."],
    crates: ["Crates & Pallets", "Heavy-duty stackable crates and pallets for logistics and retail."],
    pots: ["Plant Pots", "Weather-resistant plant pots for home, garden, and nursery use."],
    stationery: ["Stationery", "Precision-moulded plastic components for pens, files, and office supplies."]
  };

  var photos = {
    containers: "assets/products/container.jpg",
    household: "assets/products/household.jpg",
    electrical: "assets/products/electrical.jpg",
    hangers: "assets/products/hangers.jpg"
  };

  var overlay = document.createElement("div");
  overlay.className = "pm-overlay";
  overlay.innerHTML =
    '<div class="pm-card">' +
      '<button class="pm-close" aria-label="Close">&times;</button>' +
      '<div class="pm-visual"></div>' +
      '<div class="pm-body"><h3></h3><p></p><a href="contact.html" class="btn btn-primary">Enquire About This</a></div>' +
    "</div>";
  document.body.appendChild(overlay);

  function openModal(key) {
    if (!illustrations[key]) return;
    var visual = overlay.querySelector(".pm-visual");
    if (photos[key]) {
      visual.innerHTML = '<img src="' + photos[key] + '" alt="' + productInfo[key][0] + '">';
    } else {
      visual.innerHTML = illustrations[key];
    }
    overlay.querySelector(".pm-body h3").textContent = productInfo[key][0];
    overlay.querySelector(".pm-body p").textContent = productInfo[key][1];
    overlay.classList.add("open");
  }
  function openPhoto(src) {
    var visual = overlay.querySelector(".pm-visual");
    visual.innerHTML = '<img src="' + src + '" alt="Product photo">';
    overlay.querySelector(".pm-body h3").textContent = "";
    overlay.querySelector(".pm-body p").textContent = "";
    overlay.classList.add("open");
  }
  function closeModal() { overlay.classList.remove("open"); }

  overlay.addEventListener("click", function (e) {
    if (e.target === overlay) closeModal();
  });
  overlay.querySelector(".pm-close").addEventListener("click", closeModal);
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeModal();
  });

  document.querySelectorAll(".product-card").forEach(function (card) {
    card.addEventListener("click", function () {
      openModal(card.getAttribute("data-illustration"));
    });
  });

  document.querySelectorAll(".gallery-item").forEach(function (item) {
    item.addEventListener("click", function () {
      openPhoto(item.getAttribute("data-src"));
    });
  });

  // ---- Floating WhatsApp button (all pages) ----
  var wa = document.createElement("a");
  wa.href = "https://wa.me/917010851006?text=" + encodeURIComponent("Hi Runwal Plast, I'd like to enquire about your products.");
  wa.className = "whatsapp-float";
  wa.target = "_blank";
  wa.rel = "noopener";
  wa.setAttribute("aria-label", "Chat on WhatsApp");
  wa.innerHTML = '<svg viewBox="0 0 32 32"><path d="M16 3C9 3 3.3 8.6 3.3 15.5c0 2.4.7 4.7 1.9 6.7L3 29l7-1.9c1.9 1 4 1.6 6 1.6 7 0 12.7-5.6 12.7-12.5S23 3 16 3zm0 22.7c-1.9 0-3.7-.5-5.3-1.4l-.4-.2-4.2 1.1 1.1-4.1-.2-.4a10.1 10.1 0 01-1.6-5.4C5.4 9.7 10.1 5 16 5s10.6 4.7 10.6 10.5S21.9 25.7 16 25.7zm5.8-7.9c-.3-.2-1.9-.9-2.2-1-.3-.1-.5-.2-.7.2-.2.3-.8 1-1 1.2-.2.2-.4.2-.7.1-.3-.2-1.3-.5-2.5-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6.1-.1.3-.4.5-.5.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5-.1-.2-.7-1.7-1-2.3-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.4s1 2.8 1.2 3c.1.2 2 3 4.8 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.5-.1 1.9-.8 2.1-1.5.3-.7.3-1.3.2-1.5-.1-.1-.3-.2-.6-.4z"/></svg>';
  document.body.appendChild(wa);

  // ---- Sticky "Get a Quote" bar on mobile ----
  if (!document.querySelector(".nav-cta.active")) {
    var bar = document.createElement("div");
    bar.className = "sticky-cta-bar";
    bar.innerHTML = '<a href="contact.html">Get a Quote</a>';
    document.body.appendChild(bar);
  }

  // ---- Count-up animation for stat numbers ----
  var counters = document.querySelectorAll(".count-up");
  if (counters.length) {
    var animateCount = function (el) {
      var target = parseFloat(el.getAttribute("data-target"));
      var suffix = el.getAttribute("data-suffix") || "";
      var duration = 1100;
      var start = null;
      function step(ts) {
        if (!start) start = ts;
        var progress = Math.min((ts - start) / duration, 1);
        var eased = 1 - Math.pow(1 - progress, 3);
        var val = Math.floor(eased * target);
        el.textContent = val + suffix;
        if (progress < 1) {
          requestAnimationFrame(step);
        } else {
          el.textContent = target + suffix;
        }
      }
      requestAnimationFrame(step);
    };
    if ("IntersectionObserver" in window) {
      var cio = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              animateCount(entry.target);
              cio.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.4 }
      );
      counters.forEach(function (el) { cio.observe(el); });
    } else {
      counters.forEach(function (el) {
        el.textContent = el.getAttribute("data-target") + (el.getAttribute("data-suffix") || "");
      });
    }
  }
});
